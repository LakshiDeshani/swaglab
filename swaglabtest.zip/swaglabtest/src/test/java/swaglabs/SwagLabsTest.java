package swaglabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SwagLabsTest {

    WebDriver driver;
    WebDriverManagerSetup webDriverSetup = new WebDriverManagerSetup();

    private SwagLabsTest() {
    }

    public static SwagLabsTest createSwagLabsTest() {
        return new SwagLabsTest();
    }

    @BeforeClass
    public void setUp() {
        driver = webDriverSetup.initializeDriver();
    }

    @Test(priority = 1)
    public void loginTest() {
        driver.get("https://www.saucedemo.com/");

        // Perform login actions like entering credentials
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("standard_user");

        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("secret_sauce");

        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Verify login success
        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html", "Login Failed!");
    }

    @Test(priority = 2)
    public void productCatalogTest() {
        // Ensure you're logged in before starting product catalog test
        WebElement productsSection = driver.findElement(By.className("inventory_item"));

        // Verify product catalog is visible
        Assert.assertTrue(productsSection.isDisplayed(), "Product Catalog not visible!");
    }

    @Test(priority = 3)
    public void addToCartTest() {
        // Ensure you're logged in and viewing products
        WebElement addToCartButton = driver.findElement(By.xpath("//button[contains(text(),'Add to cart')]"));
        addToCartButton.click();

        // Verify item is added to the cart
        WebElement cartItem = driver.findElement(By.className("inventory_item_name"));
        Assert.assertNotNull(cartItem, "Cart is empty!");
    }

    @Test(priority = 4)
    public void checkoutTest() {
        // Ensure you're logged in and have items in the cart
        WebElement cartLink = driver.findElement(By.className("shopping_cart_link"));
        cartLink.click();

        WebElement checkoutButton = driver.findElement(By.id("checkout"));
        checkoutButton.click();

        // Fill in checkout details
        WebElement firstNameField = driver.findElement(By.id("first-name"));
        WebElement lastNameField = driver.findElement(By.id("last-name"));
        WebElement postalCodeField = driver.findElement(By.id("postal-code"));
        firstNameField.sendKeys("Test");
        lastNameField.sendKeys("User");
        postalCodeField.sendKeys("12345");

        WebElement continueButton = driver.findElement(By.id("continue"));
        continueButton.click();

        // Complete checkout process
        WebElement finishButton = driver.findElement(By.id("finish"));
        finishButton.click();

        // Verify checkout is complete
        WebElement orderConfirmation = driver.findElement(By.className("complete-header"));
        Assert.assertTrue(orderConfirmation.isDisplayed(), "Order not completed!");
    }

    @Test(priority = 5)
    public void LogoutTest() {
        // Perform logout
        WebElement menuButton = driver.findElement(By.id("react-burger-menu-btn"));
        menuButton.click();

        WebElement logoutButton = driver.findElement(By.id("logout_sidebar_link"));
        logoutButton.click();

        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/", "Logout Failed!");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
