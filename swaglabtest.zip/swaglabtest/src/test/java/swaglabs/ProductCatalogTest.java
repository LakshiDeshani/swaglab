package swaglabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

class ProductCatalogTest {
    WebDriver driver;
    WebDriverManagerSetup webDriverSetup = new WebDriverManagerSetup();

    @BeforeClass
    public void setUp() {
        driver = webDriverSetup.initializeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
    }

    @Test(priority = 2)
    public void productCatalogTest() {
        List<WebElement> products = driver.findElements(By.className("inventory_item"));
        Assert.assertTrue(products.size() > 0, "No products found in the catalog!");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
