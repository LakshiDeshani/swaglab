package swaglabs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CartTest {
    WebDriver driver;
    WebDriverManagerSetup webDriverSetup = new WebDriverManagerSetup();

    @BeforeClass
    public void setUp() {
        driver = webDriverSetup.initializeDriver();
        driver.get("https://www.saucedemo.com/");
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
    }

    @Test(priority = 3)
    public void addToCartTest() {
        driver.findElement(By.xpath("//button[contains(text(),'Add to cart')]")).click();
        driver.findElement(By.className("shopping_cart_link")).click();
        WebElement cartItem = driver.findElement(By.className("inventory_item_name"));
        Assert.assertNotNull(cartItem, "Cart is empty!");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
