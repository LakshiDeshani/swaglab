import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.time.Duration;

@Test(priority = 5)
public void logoutTest() {
    // Create WebDriverWait to wait for elements to be ready
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    // Wait for the burger menu button to be visible
    WebElement burgerMenuButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-burger-menu-btn")));
    burgerMenuButton.click();

    // Wait for the logout link to be clickable
    WebElement logoutLink = wait.until(ExpectedConditions.elementToBeClickable(By.id("logout_sidebar_link")));
    logoutLink.click();

    // Assert that the URL is the login page
    Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/", "Logout Failed!");
}

public void main() {
}

private WebDriver driver;
